-- phpMyAdmin SQL Dump
-- version 4.6.5.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 04, 2017 at 12:28 AM
-- Server version: 5.6.34
-- PHP Version: 7.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`name`, `id`) VALUES
('Soles of the Damned', 204),
('Cleft-Toe Maniac', 205);

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`brand_id`, `store_id`, `id`) VALUES
(15, 1, 1),
(15, 2, 2),
(20, 3, 3),
(20, 4, 4),
(25, 5, 5),
(25, 6, 6),
(30, 7, 7),
(30, 8, 8),
(35, 10, 10),
(40, 11, 11),
(40, 12, 12),
(45, 13, 13),
(45, 14, 14),
(50, 15, 15),
(50, 16, 16),
(55, 17, 17),
(55, 18, 18),
(60, 20, 20),
(65, 21, 21),
(65, 22, 22),
(70, 23, 23),
(70, 24, 24),
(75, 27, 25),
(75, 28, 26),
(80, 33, 27),
(80, 34, 28),
(86, 40, 30),
(93, 46, 31),
(93, 47, 32),
(100, 53, 33),
(100, 54, 34),
(107, 60, 35),
(107, 61, 36),
(114, 67, 37),
(114, 68, 38),
(121, 74, 39),
(121, 75, 40),
(128, 81, 41),
(128, 82, 42),
(129, 87, 43),
(130, 87, 44),
(135, 88, 45),
(135, 89, 46),
(136, 94, 47),
(137, 94, 48),
(142, 95, 49),
(142, 96, 50),
(143, 101, 51),
(144, 101, 52),
(149, 102, 53),
(149, 103, 54),
(150, 108, 55),
(151, 108, 56),
(156, 109, 57),
(156, 110, 58),
(157, 116, 59),
(158, 116, 60),
(163, 117, 61),
(163, 118, 62),
(168, 126, 63),
(168, 127, 64),
(169, 135, 65),
(170, 135, 66),
(175, 136, 67),
(175, 137, 68),
(176, 145, 69),
(177, 145, 70),
(182, 0, 71),
(183, 10, 72),
(184, 10, 73),
(189, 11, 74),
(189, 12, 75),
(190, 20, 76),
(191, 20, 77),
(197, 30, 78),
(198, 30, 79),
(203, 31, 80),
(203, 32, 81),
(204, 40, 82),
(205, 40, 83);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
